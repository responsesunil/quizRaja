package com.udaan.quizmaker.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table
public class Quiz {
	@Id
	@GeneratedValue
	private int id;
	
	  @ManyToMany(cascade = { CascadeType.ALL })
	    @JoinTable(
	        name = "QuizQuestionMapping", 
	        joinColumns = { @JoinColumn(name = "questionId") }, 
	        inverseJoinColumns = { @JoinColumn(name = "quizId") }
	    )
	  Set<Question> questions = new HashSet<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Set<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}

}
