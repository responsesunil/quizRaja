package com.udaan.quizmaker.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.udaan.quizmaker.entities.Question;
import com.udaan.quizmaker.entities.Quiz;
import com.udaan.quizmaker.repo.QuestionRepository;
import com.udaan.quizmaker.repo.QuizRepo;
import com.udaan.quizmaker.service.QuizService;

@Service
public class QuizServiceImpl implements QuizService {
	
	@Autowired
	QuizRepo quizRepo;
	
	@Autowired
	QuestionRepository questionRepo;

	@Override
	public Integer createQuiz(List<Integer> questionIds) {
		List<Question> questions = questionRepo.findAllById(questionIds);
		return saveQuiz(new HashSet<Question>(questions));
	}

	private Integer saveQuiz(Set<Question> questions) {
		Quiz quiz = new Quiz();
		quiz.setQuestions(questions);
		quizRepo.save(quiz);
		return quiz.getId();
	}

}
