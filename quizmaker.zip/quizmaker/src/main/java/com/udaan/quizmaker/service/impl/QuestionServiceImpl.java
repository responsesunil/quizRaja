package com.udaan.quizmaker.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.udaan.quizmaker.entities.Answers;
import com.udaan.quizmaker.entities.Question;
import com.udaan.quizmaker.exceptions.AppException;
import com.udaan.quizmaker.repo.QuestionRepository;
import com.udaan.quizmaker.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService {
	
	@Autowired
	QuestionRepository questionRepo;

	@Override
	public void createQuestion(Question question) {
		List<Answers> options = question.getOptions();
		if(options.size() < 1) {
			throw new AppException("There should be atleast one option");
		}
		checkIfCorrectAnswerAvailable(options);
		questionRepo.save(question);
	}

	private void checkIfCorrectAnswerAvailable(List<Answers> options) {
		boolean isAvailable = false;
		for(Answers answer: options) {
			if(answer.getIsCorrect() == 1) {
				isAvailable = true;
				break;
			}
		}
		if(!isAvailable) {
			throw new AppException("There should be atleast one option available with correct ans");
		}
	}

}
