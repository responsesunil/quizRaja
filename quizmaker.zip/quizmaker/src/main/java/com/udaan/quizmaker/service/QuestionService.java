package com.udaan.quizmaker.service;

import org.springframework.stereotype.Service;

import com.udaan.quizmaker.entities.Question;

@Service
public interface QuestionService {
	void createQuestion(Question question);
}
