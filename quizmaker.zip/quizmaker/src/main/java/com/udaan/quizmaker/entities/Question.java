package com.udaan.quizmaker.entities;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.lang.NonNull;

@Entity
@Table
public class Question {
	@Id
	@GeneratedValue
	private int id;
	
	@Column
	@NonNull
	private String questionDesc;
	
	@OneToMany(mappedBy = "question", cascade = { CascadeType.ALL })
	@NonNull
	private List<Answers> options;
	
	@ManyToMany(mappedBy = "questions")
    private Set<Quiz> quiz = new HashSet<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getQuestionDesc() {
		return questionDesc;
	}

	public void setQuestionDesc(String questionDesc) {
		this.questionDesc = questionDesc;
	}

	public List<Answers> getOptions() {
		return options;
	}

	public void setOptions(List<Answers> options) {
		this.options = options;
	}
}
