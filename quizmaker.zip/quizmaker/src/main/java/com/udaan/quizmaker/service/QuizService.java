package com.udaan.quizmaker.service;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface QuizService {
	Integer createQuiz(List<Integer> questionIds);
}
