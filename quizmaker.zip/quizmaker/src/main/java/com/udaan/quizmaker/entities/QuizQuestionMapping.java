package com.udaan.quizmaker.entities;

public class QuizQuestionMapping {
	
}
