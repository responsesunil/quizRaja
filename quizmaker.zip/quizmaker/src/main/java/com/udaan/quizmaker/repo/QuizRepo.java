package com.udaan.quizmaker.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.udaan.quizmaker.entities.Quiz;

public interface QuizRepo extends JpaRepository<Quiz, Long>{
	
}
